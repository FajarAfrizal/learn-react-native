import { StatusBar } from 'expo-status-bar';
import {
  FlatList,
  StyleSheet,
  Text,
  View,
  ScrollView,
  Alert,
  TouchableWithoutFeedback,
  Keyboard
} from 'react-native';
import { useState } from 'react';
import Header from './components/header';
import TodoItem from './components/todoitem';
import AddTodo from './components/addtodo';
import Sandbox from './components/sandbox';
import { MaterialIcons } from '@expo/vector-icons';
export default function App() {
  const [todos, setTodos] = useState([
    { text: 'Buy Coffee', key: '1' },
    { text: 'Create an app', key: '2' },
    { text: 'play on te switch', key: '3' },
  ])


  const pressHandler = (key) => {
    setTodos((prevTodos) => {
      return prevTodos.filter(todo => todo.key !== key)
    });
  }
  const submitHandler = (text) => {

    // alerts (text)4
    if (text.length > 3) {
      setTodos((prevTodos) => {
        return [{ text: text, key: Math.random().toString() }, ...prevTodos]
      })
    } else {
      Alert.alert('OOPS!', 'Todo harus berisikan lebih dari 3 karakter', [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
        }
      ]);
    }

  }
  return (
    // <Sandbox />
    <TouchableWithoutFeedback onPress={() => {
      Keyboard.dismiss()
      console.log('dissmissed keyboard');
    }}>
      <View style={styles.container}>
        {/* import Header */}
        <Header />
        <View style={styles.content}>
          {/* to form */}
          <AddTodo submitHandler={submitHandler} />
          <View style={styles.list}>
            <ScrollView>
              <FlatList data={todos}
                renderItem={({ item }) => (
                  // mengambil data dari import TodoItem
                  <TodoItem style={styles.data} item={item} pressHandler={pressHandler} />
                )} />
            </ScrollView>
          </View>
        </View>
        <StatusBar style="auto" />
      </View>
    </TouchableWithoutFeedback>
  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  content: {
    padding: 40
  },
  list: {
    marginTop: 20,

  },
  data: {
    marginBottom: 100,
  }
});
