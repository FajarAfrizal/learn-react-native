<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Database\QueryException;

class AuthController extends Controller
{
  public function login(Request $request)
  {
    $email = $request->input('email');
    $password = $request->input('password');

    $user = User::where('email', $email)->first();
    if (!$user || !Hash::check($password, $user->password)) {
      return response()->json([
        'message' => 'Email atau password salah.'
      ]);
    }

    $response = [
      'message' => 'Berhasil Login',
      'data' => $user->id
    ];

    return response()->json($response, Response::HTTP_OK);
  }

  public function register(Request $request)
  {

    $validator = Validator::make($request->all(),[
      'name' => 'required',
      'email' => 'required|email|unique:users',
      'password' => 'required'
      
    ],
    [
      'email.unique' => 'Email Sudah Dipakai',
      'name.required' => 'Masukan Nama Anda',
      'password.required' => 'Masukan Password anda'
    ]
  );
  

    if ($validator->fails()) {
        return response()->json($validator->errors(),
        Response::HTTP_UNPROCESSABLE_ENTITY);
    }

      // $email = $request->input('email');
      // $password = bcrypt($request->input('password'));
      // $name = $request->input('name');

      try {
        $user = User::create([
          'name' => $request->name,
          'email' => $request->email,
          'password' => bcrypt($request->password),
        ]);
        $response = [
          'message' => 'Success',
          'data' => $user
        ];
        return response()->json($response, Response::HTTP_OK);
      } catch (QueryException $e) {
        return response()->json([
          'message' => 'failed' . $e->errorInfo
        ]);
      }
    }

    public function logout(Request  $request)
    {
      $request->user->logout();
      return response()->json(['message' => 'sukses Logout'], Response::HTTP_OK);
    }
  }

