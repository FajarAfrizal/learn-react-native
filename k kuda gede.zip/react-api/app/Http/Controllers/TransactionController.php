<?php

namespace App\Http\Controllers;

use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Models\Transaction;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Symfony\Component\HttpFoundation\Response;

class TransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $transaction = Transaction::orderBy('created_at', 'DESC')->get();
        $response = [
            'message' => 'List Transaction Success order by CreatedAt',
            'data' => $transaction
        ];
        return response()->json($response, Response::HTTP_OK);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'title' => 'required',
            'description' =>'required',
            'rating' =>'required|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(),
            Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        try {
            $transaction = Transaction::create([
                'title' => $request->title,
                'description' => $request->description,
                'rating' => $request->rating,
                'user_id' => Auth::user()->id,
            ]);
            $response = [
                'message' => 'Transaction Created Success',
                'data' => $transaction
            ];

            return response()->json($response, Response::HTTP_CREATED);

        } catch (QueryException $e)  {
            return response()->json([
                'message' => 'failed ' . $e->errorInfo
            ]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $transaction = Transaction::findOrFail($id);

        


        if ($transaction == null) {
            return response()->json([
                'message' => 'Transaction not found'
            ], Response::HTTP_BAD_REQUEST);

        } else{
            $response = [
                'message' => 'Detail of Transaction resource',
                'data' => $transaction
            ];
            return response()->json($response, Response::HTTP_OK);

        }
    
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
 

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $transaction = Transaction::findOrFail($id);

        $validator = Validator::make($request->all(),[
            'title' => 'required',
            'description' =>'required',
            'rating' =>'required|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(),
            Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        try {
            $transaction = Transaction::where('id', $id)->update([
                'title' => $request->title,
                'description' => $request->description,
                'rating' => $request->rating,
            ]);
            $response = [
                'message' => 'Transaction Updated Success',
                'data' => $transaction
            ];

            return response()->json($response, Response::HTTP_OK);

        } catch (QueryException $e)  {
            return response()->json([
                'message' => 'failed ' . $e->errorInfo
            ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $transaction = Transaction::findOrFail($id);
        try {
            $transaction ->delete();

            $response = [
                'message' => 'Transaction Success Deleted',
                'data' => $transaction
            ];

            return response()->json($response, Response::HTTP_OK);

        } catch (QueryException $e)  {
            return response()->json([
                'message' => 'failed ' . $e->errorInfo
            ]);
        }

    }
}
