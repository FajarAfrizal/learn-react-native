import { createStackNavigator } from "react-navigation-stack";

import Register from "../screens/register";
import Header from "../shared/header";

const screen = {
    Register: {
        screen: Register,
        navigationOptions: ({ navigation }) => {
            return {
                headerTitle: () => <Header title="Register" navigation={navigation} />
            }
        }
    }
}

const RegisterStack = createStackNavigator(screen);
export default RegisterStack;
