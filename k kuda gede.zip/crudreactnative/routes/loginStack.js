import { createStackNavigator } from "react-navigation-stack";

import Login from "../screens/login";
import Header from "../shared/header";

const screen = {
    Login: {
        screen: Login,
        navigationOptions: ({ navigation}) => {
            return{
                headerTitle: () => <Header navigation={navigation} title = 'Login'/>,
            }
        }
    }
}

const LoginStack = createStackNavigator(screen);
export default LoginStack;
