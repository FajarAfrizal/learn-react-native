import { createDrawerNavigator } from "react-navigation-drawer";
import { createAppContainer, NavigationContainer } from "react-navigation";

import AboutStack from "./aboutStack";
import HomeStack from "./homeStack";
import LoginStack from "./loginStack";
import RegisterStack from "./registerStack";

const RootDrawerNavigator = createDrawerNavigator({
    Home: {
        screen: HomeStack,
    },
    About: {
        screen: AboutStack,      
    },
    Login: {
        screen: LoginStack,
    },
    Register: {
        screen: RegisterStack,
    }

})

export default createAppContainer(RootDrawerNavigator);