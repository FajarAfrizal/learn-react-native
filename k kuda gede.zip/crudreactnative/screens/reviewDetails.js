import React, { useState } from 'react';
import { StyleSheet, View, Text, Image, TouchableOpacity, Button } from 'react-native';
import { globalStyles, images } from '../styles/global';
import Card from '../shared/card';
import axios from 'axios';


export default function ReviewDetails({ navigation }) {

    const pressHandler = () => {
        navigation.goBack();
    }
    const rating = navigation.getParam('rating');
    const id = navigation.getParam('id');
    const title = navigation.getParam('title');
    const description = navigation.getParam('description');

    const edit = () => {
        navigation.navigate('EditRD', { id, title, description, rating });
      };

      const deleteData = async () => {
        try {
            const response = await axios.delete(`https://api.fajarafrizal.my.id/testimoni/api/transaction/delete/${id}`, {
                headers: {
                    accept: 'application/json',
                    'content-type': 'application/json'
                }
            });
            console.log(response);
            alert(`Data berhasil dihapus!`);
            navigation.navigate('Home');
        } catch (error) {
            console.error(error);
            alert('Terjadi kesalahan saat menghapus data');
        }
    };

    return (
        <View style={globalStyles.container}>
            <Card>
                <Text style={globalStyles.titleText}>Id : {navigation.getParam('id')}</Text>
                <Text style={globalStyles.titleText}>Name : {navigation.getParam('title')}</Text>
                <Text style={globalStyles.titleText}>Message : {navigation.getParam('description')}</Text>
                <View style={styles.rating}>
                    <Text  style={globalStyles.titleText}>GameZone Rating:</Text>
                    {/* images dan ratings dapat dari globalStyles sedangkan rating dapat dari parameter rating */}
                    <Image source={images.ratings[rating]} />
                </View>
            </Card>
            <TouchableOpacity style={globalStyles.button} onPress={edit}>
                <Text style={globalStyles.textButton}>Edit</Text>
            </ TouchableOpacity>

            <Button title='Delete' onPress={deleteData} color={'red'}    />


            
        </View>
    )
}

const styles = StyleSheet.create({
  rating: {
    flexDirection: 'row',
    justifyContent:'center',
    paddingTop: 16,
    marginTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#eee',
  }
})
