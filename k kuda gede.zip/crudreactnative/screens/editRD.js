import React, { useState } from 'react';
import { TextInput, StyleSheet, View, Button, Alert, Text } from 'react-native';
import axios from 'axios';

export default function EditRD({ navigation }) {
    const [title, setTitle] = useState('');
    const [rating, setRating] = useState('');
    const [description, setDescription] = useState('');

       const id = navigation.getParam('id');


    const sendData = async () => {
        // if (rating >= 1 && rating <= 5) {
        //     alert(`Data berhasil diupdate!`);
        //     setTitle('');
        //     setRating('');
        //     setDescription('');

        //     navigation.navigate('ReviewDetails')
        // } else {
        //     alert(`Masukan rating hanya 1 sampai 5 !`);
        //     setRating('');
        // }
        try {
            if (rating >= 1 && rating <= 5) {
                const response = await axios.put(`https://api.fajarafrizal.my.id/testimoni/api/transaction/update/${id}`, {
                    title: title,
                    rating: rating,
                    description: description
                }, {
                    headers: {
                        accept: 'application/json',
                        'content-type': 'application/json'
                    }
                });
                console.log(response);
            } else {
                alert(`Masukan rating hanya 1 sampai 5 !`);
                setRating('');
            }
        } catch (error) {
            console.error(error);
            if (rating === '' || title === '' || description === '' || id === '') {
                alert('Data tidak boleh kosong');
            }
        }
    };
    const home = () => {
        navigation.navigate('Home');
    }

    return (
        <View style={styles.container}>
            <Text>{id}</Text>
            <TextInput
                style={styles.input}
                placeholder="Enter Title"
                onChangeText={text => setTitle(text)}
                value={title}
                returnKeyType="next"
                clearButtonMode="always"
                accessibilityLabel="My Title Input"
            />
            <TextInput
                style={styles.input}
                placeholder="Rating (1-5)"
                onChangeText={text => setRating(text)}
                value={rating}
                returnKeyType="next"
                clearButtonMode="always"
                accessibilityLabel="My Rating Input"
                keyboardType='number-pad'
            />
            <TextInput
                style={styles.input}
                placeholder="Enter Description"
                onChangeText={text => setDescription(text)}
                value={description}
                returnKeyType="done"

                clearButtonMode="always"
                accessibilityLabel="My Description Input"
            />
            <Button title="Submit" onPress={sendData} />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        justifyContent: 'center',
        fontFamily: 'nunito-regular',
    },
    input: {
        height: 40,
        width: '100%',
        borderColor: 'gray',
        borderWidth: 1,
        padding: 10,
        marginVertical: 10,
    }
})