import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, Button } from 'react-native';
import axios from 'axios';


const Register = ({ navigation }) => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState(''); 
    const handleRegister = () => {
        axios.post('https://api.fajarafrizal.my.id/testimoni/api/register', {
            name,
            email,
            password,
        })
            .then((response) => {
                console.log(response.data);
                navigation.navigate('Login');
            })
            .catch((error) => {
                console.error(error);
            });
    };0

    const Login = () => {
        navigation.navigate('Login');
    };

    return (
        <View style={styles.container}>
            <Text style={styles.header}>Register</Text>
            <TextInput
                style={styles.textInput}
                placeholder="Name"
                onChangeText={text => setName(text)}
                value={name}
            />
            <TextInput
                style={styles.textInput}
                placeholder="Email"
                onChangeText={text => setEmail(text)}
                value={email}
            />
            <TextInput
                style={styles.textInput}
                placeholder="Password"
                secureTextEntry
                onChangeText={text => setPassword(text)}
                value={password}
            />
            
            <Button title="Submit" onPress={handleRegister} />

            <TouchableOpacity onPress={Login}>
                <Text style={styles.textCenter}>Sudah punya Akun? <Text style={styles.colorText}> Silahkan Login</Text></Text>
            </TouchableOpacity>

        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    header: {
        fontSize: 24,
        marginBottom: 20,
    },
    textInput: {
        width: '80%',
        height: 40,
        borderColor: 'gray',
        borderWidth: 1,
        marginBottom: 20,
        padding: 10,
    },
    button: {
        width: '80%',
        height: 40,
        backgroundColor: 'blue',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 20,
    },
    textCenter :{
        margin: 20,
        fontFamily: 'nunito-bold',
        fontSize: 14,
    },
    colorText: {
        color: '#63c5da',
        fontFamily: 'nunito-bold',
    }
});
export default Register;