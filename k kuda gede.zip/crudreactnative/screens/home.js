import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, Button, FlatList, TouchableOpacity, Modal } from 'react-native';
import { globalStyles } from '../styles/global';
import Card from '../shared/card';
import { MaterialIcons } from '@expo/vector-icons';
import CreateRD from './createRD';

export default function Home({ navigation, EditRD }) {
  // const [reviews, setReviews] = useState([
  //     { title: 'Review 1', rating: 4, body: 'Lorem ipsum dolor sit amet', key: '1' },
  //     { title: 'Review 2', rating: 3, body: 'Lorem ipsum dolor sit amet', key: '2' },
  //     { title: 'Review 3', rating: 2, body: 'Lorem ipsum dolor sit amet', key: '3' },
  //     { title: 'Review 4', rating: 1, body: 'Lorem ipsum dolor sit amet', key: '4' },
  // ]);
  const [isLoading, setLoading] = useState(true);
  const [data, setData] = useState([]);

  const getMovies = async () => {
    try {
      const response = await fetch('https://api.fajarafrizal.my.id/testimoni/api/transaction');
      const json = await response.json();
      setData(json.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getMovies();
  }, []);

  const [modalOpen, setModalOpen] = useState(false);


  const pressHandler = () => {
    navigation.push('ReviewDetails');
    // navigation.push('ReviewDetails');
  }
  return (
    <View style={globalStyles.container}>
      {/* <Text style={globalStyles.titleText}>Home Screens</Text> */}
      {/* <Button title='go to reviews' onPress={pressHandler}/> */}

      <Modal style={globalStyles.modal} visible={modalOpen} animationType='slide'>
        <View style={globalStyles.modalContent}>
          <MaterialIcons
            name='close'
            size={26}
            style={globalStyles.modalToggle}
            onPress={() => setModalOpen(false)}
          />
          <Text style={globalStyles.modalText}>Hello form the modal</Text>

          <CreateRD />
        </View>
      </Modal>

      <MaterialIcons
        name='add'
        size={26}
        style={globalStyles.modalToggle}
        onPress={() => setModalOpen(true)}
      />

      <FlatList
        data={data}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => navigation.navigate('ReviewDetails', item)}>
            <Card>
              <Text style={globalStyles.titleText}>{item.title}</Text>
            </Card>

          </TouchableOpacity>
        )}
      />
    
    </View>
  )

}

