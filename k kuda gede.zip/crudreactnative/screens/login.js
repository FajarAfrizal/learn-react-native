import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, Text, StyleSheet, Button } from 'react-native';
import axios from 'axios';



const Login = ({ navigation }) => {

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleLogin = () => {
        axios.post('https://api.fajarafrizal.my.id/testimoni/api/login', {
            email,
            password,
        })
            .then((response) => {
                // Handle success
                console.log(response.data);
                if (response.data.message === 'Email atau password salah.') {
                    alert('Email atau password salah');
                } else {
                    // Navigate to home screen
                    navigation.navigate('Home');
                }

            })
            .catch((error) => {
                // Handle error
                console.error(error.data);
            });
    };

    const Register = () => {
        navigation.navigate('Register');
    };
    


    return (
        <View style={styles.container}>
            <TextInput
                style={styles.input}
                placeholder="Email"
                onChangeText={(text) => setEmail(text)}
                value={email}
            />
            <TextInput
                style={styles.input}
                placeholder="Password"
                onChangeText={(text) => setPassword(text)}
                value={password}
                secureTextEntry
            />
            <Button title="Submit" onPress={handleLogin} />

            <TouchableOpacity onPress={Register}>
                <Text style={styles.textCenter}>Belum punya Akun? <Text style={styles.colorText}> Silahkan buat terlebih dahulu</Text></Text>
            </TouchableOpacity>

        </View>
    );

};
const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        alignItems: 'center',
        justifyContent: 'center',
    },
    input: {
        height: 40,
        width: '100%',
        borderColor: 'gray',
        borderWidth: 1,
        padding: 10,
        marginVertical: 10,
    },
    textCenter :{
        margin: 20,
        fontFamily: 'nunito-bold',
        fontSize: 14,
    },
    colorText: {
        color: '#63c5da',
        fontFamily: 'nunito-bold',
    }
});

export default Login;
