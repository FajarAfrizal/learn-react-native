import React, { useState } from 'react';
import { View, Text, Button } from 'react-native';

const authScreen = ({ navigation }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  if (!isLoggedIn) {
    return (
      <View>
        <Text>You are not logged in</Text>
        <Button
          title="Go to Login"
          onPress={() => navigation.navigate('Login')}
        />
      </View>
    );
  }

  return (
    <View>
      <Text>You are logged in</Text>
      <Button
        title="Go to Profile"
        onPress={() => navigation.navigate('Home')}
      />
    </View>
  );
};

export default authScreen;
