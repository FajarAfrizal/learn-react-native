import { useCallback } from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { useFonts } from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';
import Home from './screens/home';
import Navigator from './routes/drawer'
import Login from './screens/login';
import { globalStyles } from './styles/global';


SplashScreen.preventAutoHideAsync();

export default function App() {
  const [fontsLoaded] = useFonts({
    'nunito-regular': require('./assets/fots/Nunito-Regular.ttf'),
    'nunito-bold': require('./assets/fons/Nunito-Bold.ttf'),
  });

  const onLayoutRootView = useCallback(async () => {
    if (fontsLoaded) {
      await SplashScreen.hideAsync();
    }
  }, [fontsLoaded]);

  if (!fontsLoaded) {
    return null;
  }

  return (
     <Navigator onLayout={onLayoutRootView} />
    //  <View onLayout={onLayoutRootView}>
    //     <Text style = {globalStyles.titleText}>test</Text>
    //  </View>
     
  );
}


